package com.foxfriend.floating;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.provider.Settings;

/** Requests automatic reappearance after restart when the user enables it. */
public final class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (!Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction())) return;
        boolean enabled = context.getSharedPreferences(FoxOverlayService.PREFS, Context.MODE_PRIVATE)
                .getBoolean("auto_start", true);
        if (!enabled || !Settings.canDrawOverlays(context)) return;
        try {
            Intent service = new Intent(context, FoxOverlayService.class)
                    .setAction(FoxOverlayService.ACTION_START);
            if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(service);
            else context.startService(service);
        } catch (RuntimeException deniedBySystem) {
            // Android device maker power restrictions or background-launch restrictions
            // may prevent restarting a service at boot. User can reopen the app.
            android.util.Log.w("FoxFriend", "Auto-start blocked by Android", deniedBySystem);
        }
    }
}
