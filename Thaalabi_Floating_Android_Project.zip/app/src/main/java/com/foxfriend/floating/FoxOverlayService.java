package com.foxfriend.floating;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.content.SharedPreferences;

/** Persistent foreground-service companion overlaid on Android applications. */
public final class FoxOverlayService extends Service {
    public static final String ACTION_START = "com.foxfriend.floating.START";
    public static final String ACTION_STOP = "com.foxfriend.floating.STOP";
    public static final String PREFS = "fox_preferences";
    public static final String CHANNEL = "fox_overlay_status";
    private static final int NOTIFICATION_ID = 411;

    private WindowManager manager;
    private WindowManager.LayoutParams parameters;
    private FoxAnimatedView fox;
    private SharedPreferences prefs;

    @Override public void onCreate() {
        super.onCreate();
        manager = (WindowManager) getSystemService(WINDOW_SERVICE);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
    }

    private int dp(float value) {return Math.round(getResources().getDisplayMetrics().density * value);}

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            prefs.edit().putBoolean("running", false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            prefs.edit().putBoolean("running", false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        try {
            startAsForeground();
            if (fox == null) installFox();
            prefs.edit().putBoolean("running", true).apply();
        } catch (Exception exception) {
            android.util.Log.e("FoxFriend", "Could not create floating overlay", exception);
            prefs.edit().putBoolean("running", false).apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        return START_STICKY;
    }

    private void startAsForeground() {
        NotificationManager notifications = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL, "الثعلب العائم", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("تُظهر أن الثعلب يعمل، ويمكن إيقافه من الإشعار");
            channel.setShowBadge(false);
            notifications.createNotificationChannel(channel);
        }
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(this, 1, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, FoxOverlayService.class).setAction(ACTION_STOP);
        PendingIntent stopPending = PendingIntent.getService(this, 2, stop,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        Notification notification = builder
                .setSmallIcon(R.drawable.ic_fox_notification)
                .setContentTitle("ثعلبك الصغير معك 🦊")
                .setContentText("اسحب الثعلب لتغيير مكانه، أو اضغط لإيقافه")
                .setContentIntent(openPending)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .addAction(new Notification.Action.Builder(null, "إيقاف", stopPending).build())
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    private void installFox() {
        fox = new FoxAnimatedView(this);
        final int width = dp(108);
        final int height = Math.round(width * 847f / 708f);
        parameters = new WindowManager.LayoutParams(width, height,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        parameters.gravity = Gravity.TOP | Gravity.START;
        final int[] bounds = availableScreen();
        int defaultX = bounds[0] - width - dp(9);
        int defaultY = bounds[1] / 3;
        parameters.x = prefs.getInt("x", defaultX);
        parameters.y = prefs.getInt("y", defaultY);
        clamp(bounds);
        fox.setOnTouchListener(new View.OnTouchListener() {
            private float downRawX, downRawY;
            private int initialX, initialY;
            private boolean dragged;
            @Override public boolean onTouch(View v, MotionEvent event) {
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        initialX = parameters.x;
                        initialY = parameters.y;
                        dragged = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float deltaX = event.getRawX()-downRawX;
                        float deltaY = event.getRawY()-downRawY;
                        if (Math.abs(deltaX) > dp(6) || Math.abs(deltaY) > dp(6)) dragged = true;
                        if (dragged) {
                            parameters.x = initialX + (int)deltaX;
                            parameters.y = initialY + (int)deltaY;
                            clamp(availableScreen());
                            if (fox != null) manager.updateViewLayout(fox, parameters);
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (dragged) {
                            prefs.edit().putInt("x", parameters.x).putInt("y", parameters.y).apply();
                        } else if (fox != null) {
                            fox.greet();
                            fox.performClick();
                        }
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        if (dragged) {
                            prefs.edit().putInt("x", parameters.x).putInt("y", parameters.y).apply();
                        }
                        return true;
                    default: return false;
                }
            }
        });
        manager.addView(fox, parameters);
    }

    private int[] availableScreen() {
        DisplayMetrics metrics = new DisplayMetrics();
        manager.getDefaultDisplay().getRealMetrics(metrics);
        return new int[]{metrics.widthPixels, metrics.heightPixels};
    }

    private void clamp(int[] screen) {
        if (parameters == null) return;
        parameters.x = Math.max(0, Math.min(parameters.x, screen[0] - parameters.width));
        parameters.y = Math.max(dp(20), Math.min(parameters.y, screen[1] - parameters.height - dp(15)));
    }

    @Override public void onConfigurationChanged(Configuration changed) {
        super.onConfigurationChanged(changed);
        if (fox != null && parameters != null) {
            clamp(availableScreen());
            try { manager.updateViewLayout(fox, parameters); } catch (IllegalArgumentException ignored) { }
        }
    }

    @Override public void onDestroy() {
        prefs.edit().putBoolean("running", false).apply();
        if (fox != null) {
            try { manager.removeView(fox); } catch (IllegalArgumentException ignored) { }
            fox = null;
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
