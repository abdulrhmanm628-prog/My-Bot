package com.foxfriend.floating;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.SystemClock;
import android.view.View;

/**
 * Original-image based, low-frame-rate animated overlay.
 * All drawable sprites share a 708x847 logical canvas so the original pose is faithfully preserved.
 * No network requests, audio, telemetry, WebView or external animation libraries.
 */
public final class FoxAnimatedView extends View {
    private final Bitmap body, tail, leftEar, rightEar, arm, eyelids;
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private final float logicalWidth;
    private final float logicalHeight;
    private long touchTime = -100000L;
    private long nextBlink = 0L;
    private final long startTime = SystemClock.uptimeMillis();

    public FoxAnimatedView(Context context) {
        super(context);
        body = image(context, R.drawable.fox_body);
        tail = image(context, R.drawable.fox_tail);
        leftEar = image(context, R.drawable.fox_ear_left);
        rightEar = image(context, R.drawable.fox_ear_right);
        arm = image(context, R.drawable.fox_arm);
        eyelids = image(context, R.drawable.fox_blink);
        logicalWidth = body.getWidth();
        logicalHeight = body.getHeight();
        setContentDescription("الثعلب العائم، اسحبه لتغيير مكانه أو المسه ليرحب بك");
        nextBlink = startTime + 4100;
    }

    private static Bitmap image(Context context, int resource) {
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inScaled = false;
        return BitmapFactory.decodeResource(context.getResources(), resource, opts);
    }

    void greet() {
        touchTime = SystemClock.uptimeMillis();
        invalidate();
    }

    private void render(Canvas canvas, Bitmap bitmap, float pivotX, float pivotY, float rotation) {
        canvas.save();
        canvas.rotate(rotation, pivotX, pivotY);
        canvas.drawBitmap(bitmap, 0, 0, paint);
        canvas.restore();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (body.isRecycled()) return;
        final long now = SystemClock.uptimeMillis();
        final float elapsed = (now - startTime) / 1000f;
        final float greeting = Math.max(0f, 1f - (now - touchTime) / 900f);
        final float bounce = greeting * greeting * (float)Math.abs(Math.sin(elapsed * 16.0));

        float scale = Math.min(getWidth() / logicalWidth, getHeight() / logicalHeight);
        float xOffset = (getWidth() - scale * logicalWidth) * .5f;
        float yOffset = (getHeight() - scale * logicalHeight) * .5f;
        canvas.save();
        canvas.translate(xOffset, yOffset);
        canvas.scale(scale, scale);

        // A barely perceptible "breathing" motion applies to all pieces of the original image.
        float breathing = 1.0f + 0.004f * (float) Math.sin(elapsed * 2.0);
        canvas.translate(0, -5.5f * bounce - 1.6f * (float)Math.sin(elapsed*1.35f));
        canvas.scale(1, breathing, logicalWidth/2f, logicalHeight*.85f);

        // Separate transparent tail and ears make the character move without changing its identity.
        float swish = (float)Math.sin(elapsed * 1.7f) * 4.3f + (greeting * 8f * (float)Math.sin(elapsed * 10f));
        render(canvas, tail, 420f, 660f, swish);

        float twitchL = (float)(Math.pow(Math.max(0, Math.sin(elapsed*.69)), 12) * -3.5);
        float twitchR = (float)(Math.pow(Math.max(0, Math.sin(elapsed*.62+1.7)), 16) * 3.7);
        render(canvas, leftEar, 189f, 236f, twitchL);
        render(canvas, rightEar, 437f, 279f, twitchR);
        canvas.drawBitmap(body, 0f, 0f, paint);

        float wave = (float)Math.sin(elapsed*1.7f) * 1.4f + greeting * (float)Math.sin(elapsed*19f) * 9f;
        render(canvas, arm, 176f, 513f, wave);

        // Blink ~ every 4-7 seconds. A custom eyelid sprite is drawn over the original eyes.
        if (now > nextBlink + 190) nextBlink = now + 4200 + (long)(1750*Math.abs(Math.sin(elapsed)));
        if (now >= nextBlink && now <= nextBlink + 190) {
            float blinkPhase = (now - nextBlink)/190f;
            float opacity = (float)Math.pow(Math.sin(Math.PI * blinkPhase), .30);
            paint.setAlpha(Math.max(0, Math.min(255, (int)(255*opacity))));
            canvas.drawBitmap(eyelids, 0, 0, paint);
            paint.setAlpha(255);
        }
        canvas.restore();
        // ~10 fps, deliberately lower than game frame rates to reduce battery use.
        if (getWindowVisibility() == VISIBLE && isAttachedToWindow()) {
            postInvalidateDelayed(105);
        }
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        invalidate();
    }

    @Override
    protected void onVisibilityChanged(View changedView, int visibility) {
        super.onVisibilityChanged(changedView, visibility);
        if (visibility == VISIBLE) invalidate();
    }

    @Override
    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        // The framework cancels pending invalidate callbacks for detached views.
        for (Bitmap bitmap : new Bitmap[]{body, tail, leftEar, rightEar, arm, eyelids}) {
            if (!bitmap.isRecycled()) bitmap.recycle();
        }
    }
}
