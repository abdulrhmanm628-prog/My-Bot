package com.foxfriend.floating;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

/** Small RTL configuration screen; overlay itself has no visible controls. */
public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(245, 250, 250);
    private static final int TEXT = Color.rgb(34, 59, 64);
    private static final int TEAL = Color.rgb(30, 137, 135);
    private TextView state;
    private Button start;
    private boolean pendingPermissionStart;
    private SharedPreferences preferences;

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = getSharedPreferences(FoxOverlayService.PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.rgb(235,245,244));
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        buildScreen();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 102);
        }
    }

    private GradientDrawable bg(int color, int radius) {
        GradientDrawable shape = new GradientDrawable();
        shape.setColor(color);
        shape.setCornerRadius(dp(radius));
        return shape;
    }

    private TextView label(String text, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(color);
        v.setTextSize(size);
        v.setGravity(Gravity.CENTER);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private LinearLayout.LayoutParams lp(int width, int height, int bottom) {
        LinearLayout.LayoutParams l = new LinearLayout.LayoutParams(width, height);
        l.bottomMargin = dp(bottom);
        return l;
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout column = new LinearLayout(this);
        column.setOrientation(LinearLayout.VERTICAL);
        column.setGravity(Gravity.CENTER_HORIZONTAL);
        column.setPadding(dp(23), dp(30), dp(23), dp(24));
        column.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        scroll.addView(column);

        TextView heading = label("ثعلبي العائم 🦊", 29, TEXT, true);
        column.addView(heading, lp(-1,-2,7));
        TextView sub = label("صديقك الصغير فوق تطبيقات الهاتف", 15, Color.rgb(98,123,125), false);
        column.addView(sub, lp(-1,-2,15));

        ImageView hero = new ImageView(this);
        hero.setImageResource(R.drawable.fox_full);
        hero.setScaleType(ImageView.ScaleType.FIT_CENTER);
        column.addView(hero, lp(dp(168),dp(194),18));

        state = label("", 15, TEXT, true);
        state.setPadding(dp(12), dp(15), dp(12), dp(15));
        state.setBackground(bg(Color.rgb(226,243,239),17));
        column.addView(state, lp(-1,-2,20));

        start = new Button(this);
        start.setText("تشغيل الثعلب العائم ✨");
        start.setAllCaps(false);
        start.setTextSize(17);
        start.setTextColor(Color.WHITE);
        start.setBackground(bg(TEAL,17));
        start.setOnClickListener(v -> startFox());
        column.addView(start, lp(-1,dp(57),12));

        Button stop = new Button(this);
        stop.setText("إيقاف الثعلب");
        stop.setAllCaps(false);
        stop.setTextSize(16);
        stop.setTextColor(TEAL);
        stop.setBackground(bg(Color.rgb(223,238,236),17));
        stop.setOnClickListener(v -> {
            preferences.edit().putBoolean("running", false).apply();
            try { startService(new Intent(this, FoxOverlayService.class).setAction(FoxOverlayService.ACTION_STOP)); }
            catch (Exception ignored) {}
            Toast.makeText(this, "تم طلب إيقاف الثعلب", Toast.LENGTH_SHORT).show();
            updateState();
        });
        column.addView(stop, lp(-1,dp(52),16));

        Switch auto = new Switch(this);
        auto.setText("إظهار الثعلب تلقائيًا بعد إعادة تشغيل الهاتف");
        auto.setTextColor(TEXT);
        auto.setTextSize(14);
        auto.setChecked(preferences.getBoolean("auto_start", true));
        auto.setPadding(dp(4), dp(10), dp(4), dp(12));
        auto.setOnCheckedChangeListener((button, checked) -> preferences.edit()
                .putBoolean("auto_start", checked).apply());
        column.addView(auto, lp(-1,-2,14));

        TextView instructions = label("بعد التفعيل، اسحب الثعلب لتغيير مكانه.\nسيرمش ويحرك ذيله وأذنيه تلقائيًا، ويلوح عندما تلمسه.\nلا يحتاج إلى إنترنت أو حساب.", 14, Color.rgb(92,112,114), false);
        instructions.setLineSpacing(dp(4),1f);
        instructions.setPadding(dp(16),dp(18),dp(16),dp(18));
        instructions.setBackground(bg(Color.WHITE,18));
        column.addView(instructions, lp(-1,-2,8));

        TextView hint = label("يتطلب إذن «الظهور فوق التطبيقات الأخرى». قد يمنع النظام ظهوره فوق بعض الشاشات الآمنة أو يوقفه لتوفير البطارية.", 12, Color.rgb(114,129,130), false);
        column.addView(hint, lp(-1,-2,0));
        setContentView(scroll);
        updateState();
    }

    private void startFox() {
        if (!Settings.canDrawOverlays(this)) {
            pendingPermissionStart = true;
            Toast.makeText(this, "اسمح بظهور ثعلبي العائم فوق التطبيقات", Toast.LENGTH_LONG).show();
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            try { startActivity(permission); }
            catch (Exception e) {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));
            }
            return;
        }
        Intent service = new Intent(this, FoxOverlayService.class).setAction(FoxOverlayService.ACTION_START);
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
            else startService(service);
            Toast.makeText(this, "ثعلبك جاهز! افتح أي تطبيق وشاهده", Toast.LENGTH_LONG).show();
        } catch (Exception exception) {
            Toast.makeText(this, "منع النظام تشغيل الثعلب. تحقق من إعدادات الجهاز", Toast.LENGTH_LONG).show();
        }
        updateState();
    }

    private void updateState() {
        if (state == null) return;
        if (!Settings.canDrawOverlays(this)) {
            state.setText("🔒 مطلوب إذن الظهور فوق التطبيقات");
            start.setText("منح الإذن وتشغيل الثعلب");
        } else if (preferences.getBoolean("running",false)) {
            state.setText("✅ الثعلب العائم يعمل");
            start.setText("إظهار / إعادة تشغيل الثعلب");
        } else {
            state.setText("🦊 الثعلب جاهز للتشغيل");
            start.setText("تشغيل الثعلب العائم ✨");
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (pendingPermissionStart && Settings.canDrawOverlays(this)) {
            pendingPermissionStart = false;
            startFox();
        } else updateState();
    }
}
